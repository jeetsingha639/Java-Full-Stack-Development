# Java-Full-Stack
JAVA  + full stack

#Topic to be covered

javscript
1) PL
2) WEB DEVELOPMENT

a) hosting
b)higher order function
c) callbacks hells
d) promise
e)event loop
f) annonymus function
g) fetch api
h) date and time api
i) var, let, const
j) async await
k) arrow function
L) set time out

PROJECT: 

1)weather app 
2) infinite scroll 
3) stop clock
4) Drag and  drop
5) light theme & dark theme

